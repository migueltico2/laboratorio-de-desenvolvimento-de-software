package Enums;

public enum Status {
    AVAILABLE,
    CANCELLED,
    FULL
}
